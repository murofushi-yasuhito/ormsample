/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
SET NAMES utf8mb4;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE='NO_AUTO_VALUE_ON_ZERO', SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


# テーブルのダンプ OEM_MST
# ------------------------------------------------------------

DROP TABLE IF EXISTS `OEM_MST`;

CREATE TABLE `OEM_MST` (
  `OEM_ID` int(11) NOT NULL AUTO_INCREMENT COMMENT 'OEMID',
  `OEM_NM` varchar(100) NOT NULL COMMENT 'OEM名',
  `DOMAIN_NM` varchar(256) DEFAULT NULL COMMENT 'ドメイン名',
  `HEAD_TXT` varchar(100) DEFAULT NULL COMMENT 'ヘッダテキスト',
  `HEAD_LOGO_FILE` varchar(100) DEFAULT NULL COMMENT 'ヘッダロゴファイル',
  `FOOT_TXT` varchar(100) DEFAULT NULL COMMENT 'フッタテキスト',
  `FOOT_LOGO_FILE` varchar(100) DEFAULT NULL COMMENT 'フッタロゴファイル',
  `CONTRACT_DISP_KBN` char(1) NOT NULL DEFAULT '0' COMMENT '契約内容管理表示区分',
  `SUPPORT_DISP_KBN` char(1) NOT NULL DEFAULT '0' COMMENT 'サポートサイト表示区分（0：表示しない、１：表示する）',
  `BIKO` text COMMENT '備考',
  `UPDA_CMNT` text COMMENT '更新内容',
  `DELE_FLG` char(1) DEFAULT '0' COMMENT '削除フラグ',
  `UPDA_DTE` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新日時',
  `UPDA_USER_ID` int(11) NOT NULL COMMENT '更新者ID',
  `CREA_DTE` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT '作成日時',
  `CREA_USER_ID` int(11) NOT NULL COMMENT '作成者ID',
  PRIMARY KEY (`OEM_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='OEMマスタ';

LOCK TABLES `OEM_MST` WRITE;
/*!40000 ALTER TABLE `OEM_MST` DISABLE KEYS */;

INSERT INTO `OEM_MST` (`OEM_ID`, `OEM_NM`, `DOMAIN_NM`, `HEAD_TXT`, `HEAD_LOGO_FILE`, `FOOT_TXT`, `FOOT_LOGO_FILE`, `CONTRACT_DISP_KBN`, `SUPPORT_DISP_KBN`, `BIKO`, `UPDA_CMNT`, `DELE_FLG`, `UPDA_DTE`, `UPDA_USER_ID`, `CREA_DTE`, `CREA_USER_ID`)
VALUES
	(1,'ＯＥＭ２','d-nap.atk.ric24.net','ＯＥＭ１安否','head_logo_3rdwatch.gif',NULL,NULL,'1','0','OEM1が削除されてた？ので、OEM_ID=2→OEM_ID=1へ変更',NULL,'0','2020-06-01 16:10:51',588,'0000-00-00 00:00:00',0),
	(2,'ＯＥＭ２','d-nap.atk.ric24.net','ＯＥＭ２安否','head_logo_3rdwatch.gif',NULL,NULL,'1','0','OEM_ID1を複製',NULL,'0','2020-06-01 16:10:44',1,'0000-00-00 00:00:00',0),
	(4,'テスト４','test.test.co.jp','テスト４',NULL,NULL,NULL,'1','0','ああああああああああああああああああ','えええええええええええええええええええ','0','2014-09-16 13:35:34',1,'0000-00-00 00:00:00',0),
	(39,'テスト５',NULL,'テストテストテスト',NULL,NULL,NULL,'1','0',NULL,'テストOEM','0','2014-07-17 11:10:23',1,'2014-07-17 11:10:23',1),
	(41,'テスト追加名','testtesttest.co.jp','テスト追加ＯＥＭ名',NULL,NULL,NULL,'1','0','DB変更',NULL,'0','2014-11-06 10:56:19',1,'2014-11-06 10:56:19',1),
	(42,'金井ＯＥＭ','riskm.myrescue.net','テキストヘッダ','head_logo_3rdwatch.gif','テキストフッタ','foot_logo_new.gif','1','0',NULL,NULL,'0','2016-01-25 19:29:57',588,'2014-11-19 10:49:03',588),
	(43,'れすきゅうあんぴ','d-nap.atk.ric24.net','緊急情報発信支援しすてむ','head_logo_3rdwatch.gif',NULL,'foot_logo_new.gif','1','1',NULL,NULL,'0','2021-11-04 10:28:54',1,'2015-06-24 19:11:17',588),
	(44,'ｔ．ｉｓｓ２','t.iss2.myrescue.net','ｔ．ｉｓｓ２ｍｙｒｅｓｃｕｅ．ｎｅｔ',NULL,NULL,NULL,'1','0',NULL,NULL,'0','2016-01-26 16:26:35',588,'2016-01-08 12:56:44',588),
	(46,'Ｄ-ＡＮＰＩ','t-nap.ric24.net','　',NULL,NULL,NULL,'1','0',NULL,NULL,'0','2016-10-26 17:17:09',589,'2016-07-21 18:19:34',590),
	(66,'レスキュー安否確認','d-nap.atk.ric24.net','緊急情報発信支援システム（ｔｅｓｔ）','head_logo_3rdwatch.gif',NULL,'foot_logo_new.gif','0','0',NULL,NULL,'0','2020-06-01 16:10:06',588,'0000-00-00 00:00:00',0),
	(70,'ＯＥＭテスト','d-nap.atk.ric24.net','ＨｅａｄＴｅｘｔ',NULL,NULL,NULL,'1','1',NULL,'室伏テスト作成','0','2020-11-24 19:48:37',588,'2017-06-20 09:45:59',588),
	(71,'ＯＥＭテスト','domain.test','ｈｅａｄｅｒ',NULL,NULL,NULL,'0','0',NULL,NULL,'0','2019-12-05 08:51:11',588,'2019-12-05 08:50:27',588);

/*!40000 ALTER TABLE `OEM_MST` ENABLE KEYS */;
UNLOCK TABLES;



/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
